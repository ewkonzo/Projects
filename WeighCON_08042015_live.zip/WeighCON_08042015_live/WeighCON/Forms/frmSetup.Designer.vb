﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSetup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.rbnScanweigh = New System.Windows.Forms.RadioButton()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cmbcomportw = New System.Windows.Forms.ComboBox()
        Me.cmbparityw = New System.Windows.Forms.ComboBox()
        Me.cmbstopbitsw = New System.Windows.Forms.ComboBox()
        Me.cmbbaudratew = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.cmbdatabitsw = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.rbnwinscale = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Cmbcomports = New System.Windows.Forms.ComboBox()
        Me.cmbparitys = New System.Windows.Forms.ComboBox()
        Me.cmbstopbitss = New System.Windows.Forms.ComboBox()
        Me.cmbbaudrates = New System.Windows.Forms.ComboBox()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.Cmbdatabitss = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.RadioButton7 = New System.Windows.Forms.RadioButton()
        Me.rbnwin32scanner = New System.Windows.Forms.RadioButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Cmbparity = New System.Windows.Forms.ComboBox()
        Me.cmbStopBits = New System.Windows.Forms.ComboBox()
        Me.cmbBaudRate = New System.Windows.Forms.ComboBox()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.cmbPortName = New System.Windows.Forms.ComboBox()
        Me.cmbDataBits = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.rbnwin32printer = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbn5658 = New System.Windows.Forms.RadioButton()
        Me.rbn5254 = New System.Windows.Forms.RadioButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.Delay = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.chkrejection = New System.Windows.Forms.CheckBox()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.txtlastserial = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtMaxvalue = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtNodigits = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtStartvalue = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtShiftlength = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.txtUnknownItem = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.labelname52 = New System.Windows.Forms.TextBox()
        Me.txtLabelName = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.chkAcceptmaster = New System.Windows.Forms.CheckBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(542, 708)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TabControl2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage1.Size = New System.Drawing.Size(534, 675)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Lane"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Location = New System.Drawing.Point(0, 0)
        Me.TabControl2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(530, 669)
        Me.TabControl2.TabIndex = 2
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox1)
        Me.TabPage5.Location = New System.Drawing.Point(4, 29)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage5.Size = New System.Drawing.Size(522, 636)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "Lane Setup"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.rbnScanweigh)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 9)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Size = New System.Drawing.Size(506, 203)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Scan Order"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(9, 65)
        Me.RadioButton2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(160, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = " Weigh then Scan"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'rbnScanweigh
        '
        Me.rbnScanweigh.AutoSize = True
        Me.rbnScanweigh.Location = New System.Drawing.Point(9, 29)
        Me.rbnScanweigh.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rbnScanweigh.Name = "rbnScanweigh"
        Me.rbnScanweigh.Size = New System.Drawing.Size(156, 24)
        Me.rbnScanweigh.TabIndex = 1
        Me.rbnScanweigh.TabStop = True
        Me.rbnScanweigh.Text = "Scan then Weigh"
        Me.rbnScanweigh.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox5)
        Me.TabPage4.Controls.Add(Me.GroupBox6)
        Me.TabPage4.Controls.Add(Me.GroupBox4)
        Me.TabPage4.Controls.Add(Me.GroupBox3)
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(522, 636)
        Me.TabPage4.TabIndex = 4
        Me.TabPage4.Text = "Scale Setup"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.cmbcomportw)
        Me.GroupBox5.Controls.Add(Me.cmbparityw)
        Me.GroupBox5.Controls.Add(Me.cmbstopbitsw)
        Me.GroupBox5.Controls.Add(Me.cmbbaudratew)
        Me.GroupBox5.Controls.Add(Me.ComboBox2)
        Me.GroupBox5.Controls.Add(Me.cmbdatabitsw)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Location = New System.Drawing.Point(14, 277)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox5.Size = New System.Drawing.Size(500, 175)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Win32 Setting"
        '
        'cmbcomportw
        '
        Me.cmbcomportw.FormattingEnabled = True
        Me.cmbcomportw.Items.AddRange(New Object() {"COM1", "COM2", "COM3", "COM4", "COM5", "COM6"})
        Me.cmbcomportw.Location = New System.Drawing.Point(123, 29)
        Me.cmbcomportw.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbcomportw.Name = "cmbcomportw"
        Me.cmbcomportw.Size = New System.Drawing.Size(110, 28)
        Me.cmbcomportw.TabIndex = 3
        '
        'cmbparityw
        '
        Me.cmbparityw.FormattingEnabled = True
        Me.cmbparityw.Items.AddRange(New Object() {"None", "Even", "Odd"})
        Me.cmbparityw.Location = New System.Drawing.Point(363, 115)
        Me.cmbparityw.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbparityw.Name = "cmbparityw"
        Me.cmbparityw.Size = New System.Drawing.Size(110, 28)
        Me.cmbparityw.TabIndex = 2
        '
        'cmbstopbitsw
        '
        Me.cmbstopbitsw.FormattingEnabled = True
        Me.cmbstopbitsw.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbstopbitsw.Location = New System.Drawing.Point(363, 74)
        Me.cmbstopbitsw.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbstopbitsw.Name = "cmbstopbitsw"
        Me.cmbstopbitsw.Size = New System.Drawing.Size(110, 28)
        Me.cmbstopbitsw.TabIndex = 2
        '
        'cmbbaudratew
        '
        Me.cmbbaudratew.FormattingEnabled = True
        Me.cmbbaudratew.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200"})
        Me.cmbbaudratew.Location = New System.Drawing.Point(363, 29)
        Me.cmbbaudratew.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbbaudratew.Name = "cmbbaudratew"
        Me.cmbbaudratew.Size = New System.Drawing.Size(110, 28)
        Me.cmbbaudratew.TabIndex = 2
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(123, 118)
        Me.ComboBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(110, 28)
        Me.ComboBox2.TabIndex = 2
        '
        'cmbdatabitsw
        '
        Me.cmbdatabitsw.FormattingEnabled = True
        Me.cmbdatabitsw.Items.AddRange(New Object() {"7", "8", "9"})
        Me.cmbdatabitsw.Location = New System.Drawing.Point(123, 74)
        Me.cmbdatabitsw.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbdatabitsw.Name = "cmbdatabitsw"
        Me.cmbdatabitsw.Size = New System.Drawing.Size(110, 28)
        Me.cmbdatabitsw.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(248, 115)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 20)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Parity"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(248, 74)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 20)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Stop Bits"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 34)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "COM Number"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(248, 29)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 20)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Baud Rate"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 118)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 20)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Flow Control"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 74)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Data Bits."
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.Label7)
        Me.GroupBox6.Controls.Add(Me.TextBox3)
        Me.GroupBox6.Controls.Add(Me.TextBox1)
        Me.GroupBox6.Location = New System.Drawing.Point(15, 462)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox6.Size = New System.Drawing.Size(500, 134)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Winsock Setting"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 92)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 20)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Port"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 48)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 20)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "IP Adress"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(122, 88)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(350, 26)
        Me.TextBox3.TabIndex = 1
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(122, 43)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(350, 26)
        Me.TextBox1.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.RadioButton6)
        Me.GroupBox4.Controls.Add(Me.rbnwinscale)
        Me.GroupBox4.Location = New System.Drawing.Point(14, 134)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.Size = New System.Drawing.Size(500, 134)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Device  Layer"
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(18, 86)
        Me.RadioButton6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(94, 24)
        Me.RadioButton6.TabIndex = 1
        Me.RadioButton6.TabStop = True
        Me.RadioButton6.Text = "Winsock"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'rbnwinscale
        '
        Me.rbnwinscale.AutoSize = True
        Me.rbnwinscale.Location = New System.Drawing.Point(18, 45)
        Me.rbnwinscale.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rbnwinscale.Name = "rbnwinscale"
        Me.rbnwinscale.Size = New System.Drawing.Size(79, 24)
        Me.rbnwinscale.TabIndex = 0
        Me.rbnwinscale.TabStop = True
        Me.rbnwinscale.Text = "Win32"
        Me.rbnwinscale.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.CheckBox1)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 5)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.Size = New System.Drawing.Size(501, 120)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Scale Setting"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(20, 35)
        Me.CheckBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(133, 24)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Scale  Enable"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox7)
        Me.TabPage6.Controls.Add(Me.GroupBox8)
        Me.TabPage6.Controls.Add(Me.GroupBox9)
        Me.TabPage6.Location = New System.Drawing.Point(4, 29)
        Me.TabPage6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(522, 636)
        Me.TabPage6.TabIndex = 2
        Me.TabPage6.Text = "Scanner Setup"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Cmbcomports)
        Me.GroupBox7.Controls.Add(Me.cmbparitys)
        Me.GroupBox7.Controls.Add(Me.cmbstopbitss)
        Me.GroupBox7.Controls.Add(Me.cmbbaudrates)
        Me.GroupBox7.Controls.Add(Me.ComboBox9)
        Me.GroupBox7.Controls.Add(Me.Cmbdatabitss)
        Me.GroupBox7.Controls.Add(Me.Label9)
        Me.GroupBox7.Controls.Add(Me.Label10)
        Me.GroupBox7.Controls.Add(Me.Label11)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Controls.Add(Me.Label13)
        Me.GroupBox7.Controls.Add(Me.Label14)
        Me.GroupBox7.Location = New System.Drawing.Point(8, 152)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox7.Size = New System.Drawing.Size(500, 175)
        Me.GroupBox7.TabIndex = 3
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Win32 Setting"
        '
        'Cmbcomports
        '
        Me.Cmbcomports.FormattingEnabled = True
        Me.Cmbcomports.Items.AddRange(New Object() {"COM1", "COM2", "COM3", "COM4", "COM5", "COM6"})
        Me.Cmbcomports.Location = New System.Drawing.Point(123, 25)
        Me.Cmbcomports.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbcomports.Name = "Cmbcomports"
        Me.Cmbcomports.Size = New System.Drawing.Size(110, 28)
        Me.Cmbcomports.TabIndex = 3
        '
        'cmbparitys
        '
        Me.cmbparitys.FormattingEnabled = True
        Me.cmbparitys.Items.AddRange(New Object() {"None", "Even", "Odd"})
        Me.cmbparitys.Location = New System.Drawing.Point(363, 115)
        Me.cmbparitys.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbparitys.Name = "cmbparitys"
        Me.cmbparitys.Size = New System.Drawing.Size(110, 28)
        Me.cmbparitys.TabIndex = 2
        '
        'cmbstopbitss
        '
        Me.cmbstopbitss.FormattingEnabled = True
        Me.cmbstopbitss.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbstopbitss.Location = New System.Drawing.Point(363, 74)
        Me.cmbstopbitss.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbstopbitss.Name = "cmbstopbitss"
        Me.cmbstopbitss.Size = New System.Drawing.Size(110, 28)
        Me.cmbstopbitss.TabIndex = 2
        '
        'cmbbaudrates
        '
        Me.cmbbaudrates.FormattingEnabled = True
        Me.cmbbaudrates.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200"})
        Me.cmbbaudrates.Location = New System.Drawing.Point(363, 29)
        Me.cmbbaudrates.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbbaudrates.Name = "cmbbaudrates"
        Me.cmbbaudrates.Size = New System.Drawing.Size(110, 28)
        Me.cmbbaudrates.TabIndex = 2
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(123, 118)
        Me.ComboBox9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(110, 28)
        Me.ComboBox9.TabIndex = 2
        '
        'Cmbdatabitss
        '
        Me.Cmbdatabitss.FormattingEnabled = True
        Me.Cmbdatabitss.Items.AddRange(New Object() {"7", "8", "9"})
        Me.Cmbdatabitss.Location = New System.Drawing.Point(123, 74)
        Me.Cmbdatabitss.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbdatabitss.Name = "Cmbdatabitss"
        Me.Cmbdatabitss.Size = New System.Drawing.Size(110, 28)
        Me.Cmbdatabitss.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(248, 115)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 20)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Parity"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(248, 74)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 20)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Stop Bits"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(8, 34)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(105, 20)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "COM Number"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(248, 29)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 20)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Baud Rate"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(8, 118)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(97, 20)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Flow Control"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(8, 74)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(79, 20)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Data Bits."
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label15)
        Me.GroupBox8.Controls.Add(Me.Label16)
        Me.GroupBox8.Controls.Add(Me.TextBox5)
        Me.GroupBox8.Controls.Add(Me.TextBox6)
        Me.GroupBox8.Location = New System.Drawing.Point(9, 337)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox8.Size = New System.Drawing.Size(500, 134)
        Me.GroupBox8.TabIndex = 2
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Winsock Setting"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 92)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(38, 20)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Port"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 48)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(78, 20)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "IP Adress"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(122, 88)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(350, 26)
        Me.TextBox5.TabIndex = 1
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(122, 43)
        Me.TextBox6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(350, 26)
        Me.TextBox6.TabIndex = 1
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.RadioButton7)
        Me.GroupBox9.Controls.Add(Me.rbnwin32scanner)
        Me.GroupBox9.Location = New System.Drawing.Point(8, 9)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox9.Size = New System.Drawing.Size(500, 134)
        Me.GroupBox9.TabIndex = 1
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Device  Layer"
        '
        'RadioButton7
        '
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(18, 86)
        Me.RadioButton7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(94, 24)
        Me.RadioButton7.TabIndex = 1
        Me.RadioButton7.TabStop = True
        Me.RadioButton7.Text = "Winsock"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'rbnwin32scanner
        '
        Me.rbnwin32scanner.AutoSize = True
        Me.rbnwin32scanner.Location = New System.Drawing.Point(18, 45)
        Me.rbnwin32scanner.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rbnwin32scanner.Name = "rbnwin32scanner"
        Me.rbnwin32scanner.Size = New System.Drawing.Size(79, 24)
        Me.rbnwin32scanner.TabIndex = 0
        Me.rbnwin32scanner.TabStop = True
        Me.rbnwin32scanner.Text = "Win32"
        Me.rbnwin32scanner.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.GroupBox10)
        Me.TabPage7.Controls.Add(Me.GroupBox11)
        Me.TabPage7.Controls.Add(Me.GroupBox12)
        Me.TabPage7.Controls.Add(Me.GroupBox2)
        Me.TabPage7.Location = New System.Drawing.Point(4, 29)
        Me.TabPage7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(522, 636)
        Me.TabPage7.TabIndex = 3
        Me.TabPage7.Text = "Printer Setup"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Cmbparity)
        Me.GroupBox10.Controls.Add(Me.cmbStopBits)
        Me.GroupBox10.Controls.Add(Me.cmbBaudRate)
        Me.GroupBox10.Controls.Add(Me.ComboBox14)
        Me.GroupBox10.Controls.Add(Me.cmbPortName)
        Me.GroupBox10.Controls.Add(Me.cmbDataBits)
        Me.GroupBox10.Controls.Add(Me.Label17)
        Me.GroupBox10.Controls.Add(Me.Label18)
        Me.GroupBox10.Controls.Add(Me.Label19)
        Me.GroupBox10.Controls.Add(Me.Label20)
        Me.GroupBox10.Controls.Add(Me.Label21)
        Me.GroupBox10.Controls.Add(Me.Label22)
        Me.GroupBox10.Location = New System.Drawing.Point(12, 235)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox10.Size = New System.Drawing.Size(500, 175)
        Me.GroupBox10.TabIndex = 3
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Win32 Setting"
        '
        'Cmbparity
        '
        Me.Cmbparity.FormattingEnabled = True
        Me.Cmbparity.Items.AddRange(New Object() {"None", "Even", "Odd"})
        Me.Cmbparity.Location = New System.Drawing.Point(363, 115)
        Me.Cmbparity.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbparity.Name = "Cmbparity"
        Me.Cmbparity.Size = New System.Drawing.Size(110, 28)
        Me.Cmbparity.TabIndex = 2
        '
        'cmbStopBits
        '
        Me.cmbStopBits.FormattingEnabled = True
        Me.cmbStopBits.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbStopBits.Location = New System.Drawing.Point(363, 74)
        Me.cmbStopBits.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbStopBits.Name = "cmbStopBits"
        Me.cmbStopBits.Size = New System.Drawing.Size(110, 28)
        Me.cmbStopBits.TabIndex = 2
        '
        'cmbBaudRate
        '
        Me.cmbBaudRate.FormattingEnabled = True
        Me.cmbBaudRate.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200"})
        Me.cmbBaudRate.Location = New System.Drawing.Point(363, 29)
        Me.cmbBaudRate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbBaudRate.Name = "cmbBaudRate"
        Me.cmbBaudRate.Size = New System.Drawing.Size(110, 28)
        Me.cmbBaudRate.TabIndex = 2
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(123, 118)
        Me.ComboBox14.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(110, 28)
        Me.ComboBox14.TabIndex = 2
        '
        'cmbPortName
        '
        Me.cmbPortName.FormattingEnabled = True
        Me.cmbPortName.Items.AddRange(New Object() {"COM1", "COM2", "COM3", "COM4", "COM5", "COM6"})
        Me.cmbPortName.Location = New System.Drawing.Point(122, 29)
        Me.cmbPortName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbPortName.Name = "cmbPortName"
        Me.cmbPortName.Size = New System.Drawing.Size(110, 28)
        Me.cmbPortName.TabIndex = 2
        '
        'cmbDataBits
        '
        Me.cmbDataBits.FormattingEnabled = True
        Me.cmbDataBits.Items.AddRange(New Object() {"7", "8", "9"})
        Me.cmbDataBits.Location = New System.Drawing.Point(123, 74)
        Me.cmbDataBits.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbDataBits.Name = "cmbDataBits"
        Me.cmbDataBits.Size = New System.Drawing.Size(110, 28)
        Me.cmbDataBits.TabIndex = 2
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(248, 115)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(48, 20)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Parity"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(248, 74)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(74, 20)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Stop Bits"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(8, 34)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(105, 20)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "COM Number"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(248, 29)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(86, 20)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "Baud Rate"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(8, 118)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(97, 20)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Flow Control"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(8, 74)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(79, 20)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Data Bits."
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Label23)
        Me.GroupBox11.Controls.Add(Me.Label24)
        Me.GroupBox11.Controls.Add(Me.TextBox8)
        Me.GroupBox11.Controls.Add(Me.TextBox9)
        Me.GroupBox11.Location = New System.Drawing.Point(12, 420)
        Me.GroupBox11.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox11.Size = New System.Drawing.Size(500, 134)
        Me.GroupBox11.TabIndex = 2
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Winsock Setting"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 92)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(38, 20)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Port"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 48)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(78, 20)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "IP Adress"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(122, 88)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(350, 26)
        Me.TextBox8.TabIndex = 1
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(122, 43)
        Me.TextBox9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(350, 26)
        Me.TextBox9.TabIndex = 1
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.RadioButton9)
        Me.GroupBox12.Controls.Add(Me.rbnwin32printer)
        Me.GroupBox12.Location = New System.Drawing.Point(12, 112)
        Me.GroupBox12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox12.Size = New System.Drawing.Size(500, 114)
        Me.GroupBox12.TabIndex = 1
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Device  Layer"
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(9, 71)
        Me.RadioButton9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(94, 24)
        Me.RadioButton9.TabIndex = 1
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "Winsock"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'rbnwin32printer
        '
        Me.rbnwin32printer.AutoSize = True
        Me.rbnwin32printer.Location = New System.Drawing.Point(9, 29)
        Me.rbnwin32printer.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rbnwin32printer.Name = "rbnwin32printer"
        Me.rbnwin32printer.Size = New System.Drawing.Size(79, 24)
        Me.rbnwin32printer.TabIndex = 0
        Me.rbnwin32printer.TabStop = True
        Me.rbnwin32printer.Text = "Win32"
        Me.rbnwin32printer.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbn5658)
        Me.GroupBox2.Controls.Add(Me.rbn5254)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Size = New System.Drawing.Size(501, 97)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select Printer"
        '
        'rbn5658
        '
        Me.rbn5658.AutoSize = True
        Me.rbn5658.Location = New System.Drawing.Point(9, 65)
        Me.rbn5658.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rbn5658.Name = "rbn5658"
        Me.rbn5658.Size = New System.Drawing.Size(92, 24)
        Me.rbn5658.TabIndex = 0
        Me.rbn5658.TabStop = True
        Me.rbn5658.Text = "56/5800"
        Me.rbn5658.UseVisualStyleBackColor = True
        '
        'rbn5254
        '
        Me.rbn5254.AutoSize = True
        Me.rbn5254.Location = New System.Drawing.Point(9, 29)
        Me.rbn5254.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rbn5254.Name = "rbn5254"
        Me.rbn5254.Size = New System.Drawing.Size(92, 24)
        Me.rbn5254.TabIndex = 0
        Me.rbn5254.TabStop = True
        Me.rbn5254.Text = "52/5400"
        Me.rbn5254.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox16)
        Me.TabPage2.Controls.Add(Me.GroupBox15)
        Me.TabPage2.Controls.Add(Me.GroupBox14)
        Me.TabPage2.Controls.Add(Me.GroupBox13)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage2.Size = New System.Drawing.Size(534, 675)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "General"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.Delay)
        Me.GroupBox16.Controls.Add(Me.Label29)
        Me.GroupBox16.Controls.Add(Me.chkrejection)
        Me.GroupBox16.Location = New System.Drawing.Point(10, 537)
        Me.GroupBox16.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox16.Size = New System.Drawing.Size(501, 125)
        Me.GroupBox16.TabIndex = 4
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "Rejection"
        '
        'Delay
        '
        Me.Delay.Location = New System.Drawing.Point(204, 65)
        Me.Delay.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Delay.Name = "Delay"
        Me.Delay.Size = New System.Drawing.Size(66, 26)
        Me.Delay.TabIndex = 2
        Me.Delay.Text = "3"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(28, 69)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(172, 20)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "Rejection Timeout(sec)"
        '
        'chkrejection
        '
        Me.chkrejection.AutoSize = True
        Me.chkrejection.Checked = True
        Me.chkrejection.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkrejection.Location = New System.Drawing.Point(30, 32)
        Me.chkrejection.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkrejection.Name = "chkrejection"
        Me.chkrejection.Size = New System.Drawing.Size(156, 24)
        Me.chkrejection.TabIndex = 0
        Me.chkrejection.Text = "Enable Rejection"
        Me.chkrejection.UseVisualStyleBackColor = True
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.txtlastserial)
        Me.GroupBox15.Controls.Add(Me.Label30)
        Me.GroupBox15.Controls.Add(Me.txtMaxvalue)
        Me.GroupBox15.Controls.Add(Me.Label31)
        Me.GroupBox15.Controls.Add(Me.txtNodigits)
        Me.GroupBox15.Controls.Add(Me.Label32)
        Me.GroupBox15.Controls.Add(Me.txtStartvalue)
        Me.GroupBox15.Controls.Add(Me.Label33)
        Me.GroupBox15.Location = New System.Drawing.Point(9, 317)
        Me.GroupBox15.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox15.Size = New System.Drawing.Size(501, 217)
        Me.GroupBox15.TabIndex = 3
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Serial Numbering"
        '
        'txtlastserial
        '
        Me.txtlastserial.Location = New System.Drawing.Point(156, 154)
        Me.txtlastserial.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtlastserial.Name = "txtlastserial"
        Me.txtlastserial.Size = New System.Drawing.Size(250, 26)
        Me.txtlastserial.TabIndex = 2
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(9, 158)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(141, 20)
        Me.Label30.TabIndex = 1
        Me.Label30.Text = "Last serial Number"
        '
        'txtMaxvalue
        '
        Me.txtMaxvalue.Location = New System.Drawing.Point(156, 114)
        Me.txtMaxvalue.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtMaxvalue.Name = "txtMaxvalue"
        Me.txtMaxvalue.Size = New System.Drawing.Size(250, 26)
        Me.txtMaxvalue.TabIndex = 2
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(28, 118)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(121, 20)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Maximum Value"
        '
        'txtNodigits
        '
        Me.txtNodigits.Location = New System.Drawing.Point(156, 74)
        Me.txtNodigits.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtNodigits.Name = "txtNodigits"
        Me.txtNodigits.Size = New System.Drawing.Size(250, 26)
        Me.txtNodigits.TabIndex = 2
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(22, 78)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(127, 20)
        Me.Label32.TabIndex = 1
        Me.Label32.Text = "Number of Digits"
        '
        'txtStartvalue
        '
        Me.txtStartvalue.Location = New System.Drawing.Point(156, 34)
        Me.txtStartvalue.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtStartvalue.Name = "txtStartvalue"
        Me.txtStartvalue.Size = New System.Drawing.Size(250, 26)
        Me.txtStartvalue.TabIndex = 2
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(62, 38)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(89, 20)
        Me.Label33.TabIndex = 1
        Me.Label33.Text = "Start Value"
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox14.Controls.Add(Me.Label27)
        Me.GroupBox14.Controls.Add(Me.txtShiftlength)
        Me.GroupBox14.Controls.Add(Me.Label26)
        Me.GroupBox14.Location = New System.Drawing.Point(10, 194)
        Me.GroupBox14.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox14.Size = New System.Drawing.Size(501, 120)
        Me.GroupBox14.TabIndex = 2
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Shift Definations"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.DateTimePicker1.Location = New System.Drawing.Point(156, 75)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.ShowUpDown = True
        Me.DateTimePicker1.Size = New System.Drawing.Size(250, 26)
        Me.DateTimePicker1.TabIndex = 3
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(22, 78)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(128, 20)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Shift 1 Start time"
        '
        'txtShiftlength
        '
        Me.txtShiftlength.Location = New System.Drawing.Point(156, 34)
        Me.txtShiftlength.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtShiftlength.Name = "txtShiftlength"
        Me.txtShiftlength.Size = New System.Drawing.Size(250, 26)
        Me.txtShiftlength.TabIndex = 2
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(9, 38)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(148, 20)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Shift Length in (hrs)"
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.txtUnknownItem)
        Me.GroupBox13.Controls.Add(Me.Label34)
        Me.GroupBox13.Controls.Add(Me.Label28)
        Me.GroupBox13.Controls.Add(Me.labelname52)
        Me.GroupBox13.Controls.Add(Me.txtLabelName)
        Me.GroupBox13.Controls.Add(Me.Label25)
        Me.GroupBox13.Controls.Add(Me.chkAcceptmaster)
        Me.GroupBox13.Location = New System.Drawing.Point(9, 9)
        Me.GroupBox13.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox13.Size = New System.Drawing.Size(501, 188)
        Me.GroupBox13.TabIndex = 1
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Scale Setting"
        '
        'txtUnknownItem
        '
        Me.txtUnknownItem.Location = New System.Drawing.Point(186, 68)
        Me.txtUnknownItem.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtUnknownItem.Name = "txtUnknownItem"
        Me.txtUnknownItem.Size = New System.Drawing.Size(217, 26)
        Me.txtUnknownItem.TabIndex = 4
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(9, 154)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(162, 20)
        Me.Label34.TabIndex = 3
        Me.Label34.Text = "Label Name(52/5400)"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(9, 112)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(162, 20)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "Label Name(56/5800)"
        '
        'labelname52
        '
        Me.labelname52.Location = New System.Drawing.Point(186, 149)
        Me.labelname52.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.labelname52.Name = "labelname52"
        Me.labelname52.Size = New System.Drawing.Size(220, 26)
        Me.labelname52.TabIndex = 2
        '
        'txtLabelName
        '
        Me.txtLabelName.Location = New System.Drawing.Point(186, 108)
        Me.txtLabelName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtLabelName.Name = "txtLabelName"
        Me.txtLabelName.Size = New System.Drawing.Size(220, 26)
        Me.txtLabelName.TabIndex = 2
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(9, 69)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(152, 20)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Item code not found"
        '
        'chkAcceptmaster
        '
        Me.chkAcceptmaster.AutoSize = True
        Me.chkAcceptmaster.Location = New System.Drawing.Point(20, 35)
        Me.chkAcceptmaster.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkAcceptmaster.Name = "chkAcceptmaster"
        Me.chkAcceptmaster.Size = New System.Drawing.Size(290, 24)
        Me.chkAcceptmaster.TabIndex = 0
        Me.chkAcceptmaster.Text = "Accept Item Master Items not found"
        Me.chkAcceptmaster.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(534, 675)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Company"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(429, 711)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 35)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Ok"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(549, 754)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TabControl1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmSetup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Setup"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbnScanweigh As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbn5658 As System.Windows.Forms.RadioButton
    Friend WithEvents rbn5254 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbparityw As System.Windows.Forms.ComboBox
    Friend WithEvents cmbstopbitsw As System.Windows.Forms.ComboBox
    Friend WithEvents cmbbaudratew As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbdatabitsw As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents rbnwinscale As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbparitys As System.Windows.Forms.ComboBox
    Friend WithEvents cmbstopbitss As System.Windows.Forms.ComboBox
    Friend WithEvents cmbbaudrates As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents Cmbdatabitss As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton7 As System.Windows.Forms.RadioButton
    Friend WithEvents rbnwin32scanner As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Cmbparity As System.Windows.Forms.ComboBox
    Friend WithEvents cmbStopBits As System.Windows.Forms.ComboBox
    Friend WithEvents cmbBaudRate As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbDataBits As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton9 As System.Windows.Forms.RadioButton
    Friend WithEvents rbnwin32printer As System.Windows.Forms.RadioButton
    Friend WithEvents cmbPortName As System.Windows.Forms.ComboBox
    Friend WithEvents Cmbcomports As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcomportw As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtShiftlength As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents chkAcceptmaster As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents txtlastserial As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtMaxvalue As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtNodigits As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtStartvalue As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtLabelName As System.Windows.Forms.TextBox
    Friend WithEvents txtUnknownItem As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents Delay As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents chkrejection As System.Windows.Forms.CheckBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents labelname52 As System.Windows.Forms.TextBox
End Class
