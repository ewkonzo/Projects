﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OfficeOpenXml;
using System.IO;
using System.Data;

namespace HIMS
{
    public partial class SendBulkSMS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        

       

         
    }
}