package com.example.pawdep;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;
public class transViewModel extends AndroidViewModel {
    private Repository repository;
    private LiveData<List<Trans>> allNotes;
   private BaseDao<member> tdao  ;
    public transViewModel(@NonNull Application application) {
        super(application);
        repository = new Repository(application,tdao );
        allNotes = repository.getAll();
    }
    public LiveData<List<Trans>> getAllNotes() {
        return allNotes;
    }
public void insert(Trans t)
{
    repository.insert(t);
}
}
