package com.example.pawdep;


import android.arch.persistence.db.SimpleSQLiteQuery;
import android.arch.persistence.db.SupportSQLiteQuery;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.RawQuery;
import android.arch.persistence.room.Update;
import android.support.v7.widget.LinearLayoutCompat;

import java.lang.reflect.ParameterizedType;
import java.util.List;


public  interface  BaseDao<T> {
    @Insert
         void insert(T t);

    @Update
         void Update(T t);

    @Delete
          abstract    void Delete(T t);
}
