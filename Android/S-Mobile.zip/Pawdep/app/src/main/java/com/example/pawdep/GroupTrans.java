package com.example.pawdep;


import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;


public class GroupTrans extends AppCompatActivity {
    public static final int ADD_TRANS = 1;
    transViewModel tmodel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tmodel = ViewModelProviders.of(this)
                .get(transViewModel.class);
       // GrouplistitemsBinding b = DataBindingUtil.setContentView(this, R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final NoteAdapter adapter = new NoteAdapter();
        recyclerView.setAdapter(adapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.trans, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.newrans:
                add();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void add() {
        Intent data = new Intent();
        Intent intent = new Intent(GroupTrans.this, addedittrans.class);
        Trans  t = new Trans();
        t.Group_Code = "new";
        intent.putExtra("Trans",t);
        startActivityForResult(intent, ADD_TRANS);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_TRANS && resultCode == RESULT_OK) {
            Trans t =(Trans) data.getSerializableExtra("Trans");
            Toast.makeText(this, t.Group_Code, Toast.LENGTH_SHORT).show();
            tmodel.insert(t);
        }
    }
}
