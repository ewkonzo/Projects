package com.example.pawdep;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;

import java.util.List;



@Dao
public abstract class agentdao  implements BaseDao<agent>  {


}
