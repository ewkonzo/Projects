package info.msacco.tabsswipe.adapter;

public interface FragmentCommunicator {
	   public void passDataToFragment(String [] titles, double[] deposits, double[] withdrawals);
}
