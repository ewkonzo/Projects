/** Automatically generated file. DO NOT MODIFY */
package com.msacco.safaricom_sacco;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}