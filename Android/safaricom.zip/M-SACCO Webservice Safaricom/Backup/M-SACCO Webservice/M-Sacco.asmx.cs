﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
namespace M_SACCO_Webservice
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Service1 : System.Web.Services.WebService
    {
        string server, db, user, pass,Companyname;
        Data data = null;
        SqlDataReader r;
        private void getsettings()
        {
            using (StreamReader sr = new StreamReader(@"c:\Mobile.txt"))
            {
                server = sr.ReadLine();
                db = sr.ReadLine();
                user = sr.ReadLine();
                pass = sr.ReadLine();
                Companyname = sr.ReadLine();
                CUtilities.logpath = sr.ReadLine();
            }
        }
        [WebMethod]
        public string WithAccounts(string Phone)
        {
            CUtilities.LogEntryOnFile(Phone);
            Phone = "+" + Phone.Replace("+", "").Trim();
            string Numbers = "";
            getsettings();
            data = new Data(server, db, user, pass);
            System.Data.DataTable reg = data.Getdatatable("SELECT * FROM ["+ Companyname + "$Vendor] WHERE [MPESA Mobile No] = '" + Phone + "'");
            if (reg.Rows.Count > 0)
            {
                foreach (System.Data.DataRow r in reg.Rows)
                {
                    Numbers += r["No_"].ToString() + "|";
                }

            }
            data.close();
            return Numbers;

        }
        private string gettime()
        {
            return "1754-01-01 " + DateTime.Now.ToString("HH:mm:ss tt");
        }


        [WebMethod]
        public string BalanceEnquiryfull(string Phone)
        {
            string balance = "";
            getsettings();
            Phone = "+" + Phone.Replace("+", "").Trim();
            data = new Data(server, db, user, pass);

            r = data.ReadDB("SELECT SUM(["+ Companyname +"$Detailed Vendor Ledg_ Entry].Amount) * - 1 - ["+ Companyname +"$Account Types].[Minimum Balance]-(Select sum([Amount]) from [dbo].["+ Companyname +"$ATM Transactions] where [Account No] = v.[No_] )  AS Balance FROM  ["+ Companyname +"$Vendor Ledger Entry] INNER JOIN ["+ Companyname +"$Vendor] v ON ["+ Companyname +"$Vendor Ledger Entry].[Vendor No_] = v.No_ INNER JOIN   ["+ Companyname +"$Detailed Vendor Ledg_ Entry] ON ["+ Companyname +"$Vendor Ledger Entry].[Entry No_] = ["+ Companyname +"$Detailed Vendor Ledg_ Entry].[Vendor Ledger Entry No_] INNER JOIN     ["+ Companyname +"$Account Types] ON v.[Account Type] = ["+ Companyname +"$Account Types].Code WHERE (v.[MPESA Mobile No] = '" + Phone + "') GROUP BY ["+ Companyname +"$Account Types].[Minimum Balance],v.[No_]");

            //r = data.ReadDB("SELECT     convert(decimal(10,2),SUM(["+ Companyname +"$Detailed Cust_ Ledg_ Entry].Amount)) AS balance, ["+ Companyname +"$Loans].[Loan Product Type] AS [TYPE] FROM ["+ Companyname +"$Loans] LEFT OUTER JOIN ["+ Companyname +"$Detailed Cust_ Ledg_ Entry] ON["+ Companyname +"$Loans].[Loan  No_] = ["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Loan No] RIGHT OUTER JOIN ["+ Companyname +"$Customer] ON ["+ Companyname +"$Loans].[Client Code] = ["+ Companyname +"$Customer].No_ WHERE (["+ Companyname +"$Customer].[Mobile Phone No] = '" + Phone + "') AND (["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Transaction Type] = 2 OR ["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Transaction Type] = 3 OR ["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Transaction Type] = 5 OR["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Transaction Type] = 15 OR["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Transaction Type] = 6)GROUP BY  ["+ Companyname +"$Loans].[Loan  No_],["+ Companyname +"$Loans].[Loan Product Type] having SUM(["+ Companyname +"$Detailed Cust_ Ledg_ Entry].Amount)>0 union all SELECT    convert(decimal(10,2), SUM(["+ Companyname +"$Detailed Cust_ Ledg_ Entry].Amount)) *-1 AS balance,'Deposits'FROM ["+ Companyname +"$Detailed Cust_ Ledg_ Entry] RIGHT OUTER JOIN["+ Companyname +"$Customer] ON ["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Customer No_] = ["+ Companyname +"$Customer].No_ WHERE  (["+ Companyname +"$Customer].[Mobile Phone No] = '" + Phone + "') and   (["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Transaction Type] = 8)GROUP BY ["+ Companyname +"$Customer].No_");
            if (r.HasRows)
            {
                while (r.Read())
                {
                    balance = Convert.ToString(r["Balance"]) ;
                }

            }
            data.close();
            return balance;
        }[WebMethod]
        public string Ministatement(string Account)
        {
            string balance = "";
            getsettings();
            data = new Data(server, db, user, pass);
                    Account = "+254" + Account.Substring(Account.Length - 9);
    CUtilities.LogEntryOnFile(Account);
            r = data.ReadDB("SELECT  top(5) convert(nvarchar(10),["+ Companyname +"$Cust_ Ledger Entry].[Posting Date],105) +'; '+ ["+ Companyname +"$Cust_ Ledger Entry].Description +'; '+ convert(nvarchar(50),convert(decimal(10,2),["+ Companyname +"$Detailed Cust_ Ledg_ Entry].Amount)) FROM["+ Companyname +"$Cust_ Ledger Entry] RIGHT OUTER JOIN ["+ Companyname +"$Customer] ON ["+ Companyname +"$Cust_ Ledger Entry].[Customer No_] = ["+ Companyname +"$Customer].No_ LEFT OUTER JOIN["+ Companyname +"$Detailed Cust_ Ledg_ Entry] ON["+ Companyname +"$Cust_ Ledger Entry].[Entry No_] = ["+ Companyname +"$Detailed Cust_ Ledg_ Entry].[Cust_ Ledger Entry No_]WHERE(["+ Companyname +"$Customer].[Mobile Phone No] = '"+Account +"')ORDER BY ["+ Companyname +"$Cust_ Ledger Entry].[Entry No_] DESC");
            if (r.HasRows)
            {
                while (r.Read())
                {
                    balance += r[0].ToString() +  ":\n";
                }

            }
            data.close();
            return balance;
        }

        //[WebMethod]
        //public string Disburseloans()
        //{
        //    getsettings();
        //    data = new Data(server, db, user, pass);
        ////r= data.ReadDB()
        
        
        //}
        [WebMethod]
        public string AccountBalance(string account)
        {
            double balance = 0;
            getsettings();
            data = new Data(server, db, user, pass);

            r = data.ReadDB("SELECT        [" + Companyname + "$Account Types].Description, ISNULL( SUM([" + Companyname + "$Detailed Vendor Ledg_ Entry].Amount)*-1  - [" + Companyname + "$Account Types].[Minimum Balance],0) AS Balance FROM [" + Companyname + "$Account Types] RIGHT OUTER JOIN  [" + Companyname + "$Vendor] ON [" + Companyname + "$Account Types].Code = [" + Companyname + "$Vendor].[Account Type] LEFT OUTER JOIN [" + Companyname + "$Detailed Vendor Ledg_ Entry] RIGHT OUTER JOIN [" + Companyname + "$Vendor Ledger Entry] ON [" + Companyname + "$Vendor Ledger Entry].[Entry No_] = [" + Companyname + "$Detailed Vendor Ledg_ Entry].[Vendor Ledger Entry No_] ON  [" + Companyname + "$Vendor].No_ = [" + Companyname + "$Vendor Ledger Entry].[Vendor No_]WHERE ([" + Companyname + "$Vendor].[No_]= '" + account + "')GROUP BY [" + Companyname + "$Vendor].[Account Type], [" + Companyname + "$Account Types].Description, [" + Companyname + "$Account Types].[Minimum Balance]");
            if (r.HasRows)
            {
                while (r.Read())
                {
                    balance = Convert.ToDouble(r["Balance"]);

                }

            }
            r.Close();
            double atm=0;
            r = data.ReadDB("select isnull(sum (Amount),0) as Balance from ["+ Companyname + "$ATM Transactions] where Posted=0 and [Account No]='" + account + "'");
            if (r.HasRows)
            {
                while (r.Read())
                {
                    

                    atm = Convert.ToDouble(r["Balance"]);

                }

            }
            balance = balance - atm;

            data.close();
            return balance.ToString();
        }
        [WebMethod]
        public string WithRequest(string phone, string Traceid, string AccountNo, double Amount)
        {
            string results;
            try
            {
                getsettings();
                data = new Data(server, db, user, pass);
                data.WriteDB("INSERT INTO [" + Companyname + "$ATM Transactions]([Trace ID],[Posting Date],[Account No],[Description],[Amount],[Posting S],[Posted],[Unit ID],[Transaction Type],[Trans Time],[Transaction Date],[Process Code],[Reversed],[Reversed Posted],[Reversal Trace ID],[Transaction Description],[Withdrawal Location],[Source],[Transaction Type Charges],[Card Acceptor Terminal ID],[ATM Card No],[TransCode],[Transaction Time],[Reference No],[Is Coop Bank],[POS Vendor],[Customer Names]) VALUES(" + Traceid + ",'" + CUtilities.FormatDate(DateTime.Now, true) + "','" + AccountNo + "','MPESA Withdrawal - " + phone + "'," + Amount + ",'" + CUtilities.FormatDate(DateTime.Now, true) + "',0,'M-PESA','Withdrawal','" + gettime() + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','M-PESA',0,0,0,'MPESA Withdrawal - " + phone + "','M-SACCO',0,0,'','','','" + gettime() + "','',0,0,'')");
                results = "OK";
            }
            catch (Exception ex)
            {
                results = "Error: " + ex.Message;
                CUtilities.LogEntryOnFile(ex.Message);
            }
            data.close();
        
            return results;
        }

        [WebMethod]
        public string WithConfirm(string recieptno, string description, string phone, string transactiontype, string AccountNo, double Amount)
        {
            string result = "OK";
            try
            {
                getsettings();
                data = new Data(server, db, user, pass);
                data.WriteDB("if not exists(SELECT * FROM ["+ Companyname + "$MPESA Transactions] WHERE [Document No_] = '" + recieptno + "' AND [Transaction Type]='Withdrawal' AND Description='" + description + "') INSERT INTO ["+ Companyname + "$MPESA Transactions]([Document No_],[Description],[Transaction Date],[Account No_],[Amount],[Posted],[Transaction Type],[Transaction Time],[Bal_ Account No_],[Document Date],[Date Posted],[Account Status],[Account Balance],[Time Posted],Messages,[Needs Change],[Change Transaction No],[Old Account No],Changed,[Date Changed],[Time Changed],[Changed By],[Approved By],[Original Account No])     VALUES('" + recieptno + "','" + description + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','" + AccountNo + "'," + Amount + ",0,'" + transactiontype + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','','" + CUtilities.FormatDate(DateTime.Now, true) + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','811101'," + AccountBalance(AccountNo) + ",'" + gettime() + "','',0,'','',0,'" + CUtilities.FormatDate(DateTime.Now, true) + "','" + gettime() + "','','','')");
            }
            catch (Exception ex)
            {
                result = ex.Message;
                CUtilities.LogEntryOnFile(ex.Message);
            }
            data.close();
            return result;
        }
        [WebMethod]
        public string WithDecline(string Traceid)
        {
            string result = "OK";
            try
            {
                getsettings();
                data = new Data(server, db, user, pass);
                data.WriteDB("Update ["+ Companyname + "$ATM Transactions] set Posted =1 where [Trace ID] = "+Traceid  +" and [Unit ID] = 'M-PESA' ");
            } 
            catch (Exception ex)
            {
                result = ex.Message;
                CUtilities.LogEntryOnFile(ex.Message);
            }
            data.close();
            return result;
        }
        private string getaccount(string idno)
        {
            string Numbers = "";
            getsettings();
            data = new Data(server, db, user, pass);
            System.Data.DataTable reg = data.Getdatatable("SELECT  * FROM ["+ Companyname + "$Vendor] WHERE [ID No_] = '" + idno + "'");
            if (reg.Rows.Count > 0)
            {
                foreach (System.Data.DataRow r in reg.Rows)
                {
                    Numbers += r["No_"].ToString() + "|";
                }

            }
            data.close();
            return Numbers;
        }

        [WebMethod]
        public string Deposit(string recieptno, string description, string phone, string transactiontype, string AccountNo, double Amount)
        {
            string result = "OK";
            try
            {
                getsettings();
                data = new Data(server, db, user, pass);
                data.WriteDB("if not exists(SELECT * FROM ["+ Companyname + "$MPESA Transactions] WHERE [Document No_] = '" + recieptno + "' AND [Transaction Type]='Deposit') INSERT INTO ["+ Companyname + "$MPESA Transactions]([Document No_],[Description],[Transaction Date],[Account No_],[Amount],[Posted],[Transaction Type],[Transaction Time],[Bal_ Account No_],[Document Date],[Date Posted],[Account Status],[Account Balance],[Time Posted],Messages,[Needs Change],[Change Transaction No],[Old Account No],Changed,[Date Changed],[Time Changed],[Changed By],[Approved By],[Original Account No])     VALUES('" + recieptno + "','" + description + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','" + getaccount(AccountNo) + "'," + Amount + ",0,'" + transactiontype + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','','" + CUtilities.FormatDate(DateTime.Now, true) + "','" + CUtilities.FormatDate(DateTime.Now, true) + "','811101',0,'" + gettime() + "','',0,'','',0,'" + CUtilities.FormatDate(DateTime.Now, true) + "','" + gettime() + "','','','')");
            }
            catch (Exception ex)
            {
                result = ex.Message;
                CUtilities.LogEntryOnFile(ex.Message);
            }
            data.close();
            return result;
        }
        [WebMethod]
        public string Advance(string Entryno, string AccountNo, double Amount)
        {
            string result = "OK";
            try
            {
                getsettings();
                data = new Data(server, db, user, pass);
                data.WriteDB("INSERT INTO [dbo].["+ Companyname + "$Loans]([Loan  No_],[Application Date],[Loan Product Type],[Client Code],[Group Code],[Savings],[Existing Loan],[Requested Amount],[Approved Amount],[Interest],[Insurance],[Source of Funds],[Client Cycle],[Client Name],[Loan Status],[Issued Date],[Installments],[Loan Disbursement Date],[Mode of Disbursement],[Affidavit - Item 1 Details],[Affidavit - Estimated Value 1],[Affidavit - Item 2 Details],[Affidavit - Estimated Value 2],[Affidavit - Item 3 Details],[Affidavit - Estimated Value 3],[Affidavit - Item 4 Details],[Affidavit - Estimated Value 4],[Affidavit - Item 5 Details],[Affidavit - Estimated Value 5],[Magistrate Name],[Date for Affidavit],[Name of Chief_ Assistant],[Affidavit Signed?],[Date Approved],[Grace Period],[Instalment Period],[Repayment],[Pays Interest During GP],[Percent Repayments],[Paying Bank Account No],[No_ Series],[Loan Product Type Name],[Cheque Number],[Doc No Used],[Batch No_],[Edit Interest Rate],[Posted],[Product Code],[Field Office],[Dimension],[Amount Disbursed],[Fully Disbursed],[New Interest Rate],[New No_ of Instalment],[New Grace Period],[New Regular Instalment],[Loan Balance at Rescheduling],[Loan Reschedule],[Date Rescheduled],[Reschedule by],[Flat Rate Principal],[Flat rate Interest],[Total Repayment],[Interest Calculation Method],[Edit Interest Calculation Meth],[Balance BF],[Cheque Date],[Loan to Share Ratio],[Shares Balance],[Max_ Installments],[Max_ Loan Amount],[Loan Cycle],[Repayment Method],[Grace Period - Principle (M)],[Grace Period - Interest (M)],[Adjustment],[Payment Due Date],[Tranche Number],[Amount Of Tranche],[Total Disbursment to Date],[Copy of ID],[Contract],[Payslip],[Contractual Shares],[Appraisal Status],[Global Dimension 1 Code],[Repayment Start Date],[Installment Including Grace],[Repayments BF],[Account No],[BOSA No],[Staff No],[BOSA Loan Amount],[Loan Received],[Cheque No_],[Personal Loan Off-set],[Old Account No_],[Loan Principle Repayment],[Loan Interest Repayment],[Contra Account],[Transacting Branch],[Source],[Net Income],[Shares Boosted],[Basic Pay],[House Allowance],[Other Allowance],[Total Deductions],[Cleared Effects],[Remarks],[Advice],[Bridging Loan Posted],[BOSA Loan No_],[Previous Repayment],[No Loan in MB],[Recovered Balance],[Recon Issue],[Loan Purpose],[Reconciled],[Appeal Amount],[Appeal Posted],[Project Amount],[Project Account No],[Discounted Amount],[Transport Allowance],[Mileage Allowance],[System Created],[Boosting Commision],[Voluntary Deductions],[4 % Bridging],[Defaulted],[Bridging Posting Date],[Commitements Offset],[Gender],[Captured By],[Branch Code],[Recovered From Guarantor],[Guarantor Amount],[External EFT],[Defaulter Overide Reasons],[Defaulter Overide],[Other Benefits],[Recovered Loan],[1st Notice],[2nd Notice],[Final Notice],[Last Advice Date],[Advice Type],[Compound Balance],[Repayment Rate],[ID NO],[RAmount],[Employer Code],[Lst LN1],[Lst LN2],[Loans Category],[Loans Category-SASRA],[Bela Branch],[Net Amount],[Bank code],[Bank Name],[Bank Branch],[Defaulter],[DefaulterInfo],[Total Earnings(Salary)],[Total Deductions(Salary)],[Share Purchase],[Product Currency Code],[Sacco Customer No_],[Total Interest[For the period]]],[Average[Monthly Interest]]],[Monthly Repayment],[Monthly Interest],[Repayment Mode],[Vendor No_],[ConfirmVendorNumber],[Fosa Main[Bank]]],[Last pay Date[Old]]]) " +
                    "( select 'MB " + Entryno + "',	" +      //Loan  No_, varchar(20)
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "'," +     //Application Date, datetime
                    "'JIENJOYI',	           " +                               //Loan Product Type, varchar(20)
                    "'" + AccountNo + "',	           " +                       //Client Code, varchar(20)
                    "'',	           " +   //Group Code, varchar(10)
                    "0,	                        " +   //Savings, decimal(38,20)
                    "0,	                        " +   //Existing Loan, decimal(38,20)
                    " " + Amount + " ,	           " +   //Requested Amount, decimal(38,20)
                    " " + Amount + " ,	           " +   //Approved Amount, decimal(38,20)
                    "0,	           " +   //Interest, decimal(38,20)
                    "0,	           " +   //Insurance, decimal(38,20)
                    "'',	           " +   //Source of Funds, varchar(20)
                    "0,	           " +   //Client Cycle, int
                    "Name,	           " +   //Client Name, varchar(50)
                    "0,	           " +   //Loan Status, int
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Issued Date, datetime
                    "1,	           " +   //Installments, int
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Loan Disbursement Date, datetime
                    "2,	           " +   //Mode of Disbursement, int
                    "'',	           " +   //Affidavit - Item 1 Details, varchar(100)
                    "0,	           " +   //Affidavit - Estimated Value 1, decimal(38,20)
                    "'',	           " +   //Affidavit - Item 2 Details, varchar(100)
                    "0,	           " +   //Affidavit - Estimated Value 2, decimal(38,20)
                    "'',	           " +   //Affidavit - Item 3 Details, varchar(100)
                    "0,	           " +   //Affidavit - Estimated Value 3, decimal(38,20)
                    "'',	           " +   //Affidavit - Item 4 Details, varchar(100)
                    "0,	           " +   //Affidavit - Estimated Value 4, decimal(38,20)
                    "'',	           " +   //Affidavit - Item 5 Details, varchar(100)
                    "0,	           " +   //Affidavit - Estimated Value 5, decimal(38,20)
                    "'',	           " +   //Magistrate Name, varchar(30)
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Date for Affidavit, datetime
                    "'',	           " +   //Name of Chief_ Assistant, varchar(30)
                    "0,	           " +   //Affidavit Signed?, tinyint
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Date Approved, datetime
                    "'',	           " +   //Grace Period, varchar(32)
                    "1,	           " +   //Instalment Period, varchar(32)
                    "" + Amount + " ,	           " +   //Repayment, decimal(38,20)
                    "0,	           " +   //Pays Interest During GP, tinyint
                    "0,	           " +   //Percent Repayments, decimal(38,20)
                    "'',	           " +   //Paying Bank Account No, varchar(20)
                    "'',	           " +   //No_ Series, varchar(10)
                    "'',	           " +   //Loan Product Type Name, varchar(100)
                    "'',	           " +   //Cheque Number, varchar(20)
                    "'',	           " +   //Doc No Used, varchar(10)
                    "'',	           " +   //Batch No_, varchar(20)
                    "0,	           " +   //Edit Interest Rate, tinyint
                    "0,	           " +   //Posted, tinyint
                    "'',	           " +   //Product Code, varchar(20)
                    "'',	           " +   //Field Office, varchar(20)
                    "'',	           " +   //Dimension, varchar(20)
                    "0,	           " +   //Amount Disbursed, decimal(38,20)
                    "0,	           " +   //Fully Disbursed, tinyint
                    "0,	           " +   //New Interest Rate, decimal(38,20)
                    "0,	           " +   //New No_ of Instalment, int
                    "'',	           " +   //New Grace Period, varchar(32)
                    "'',	           " +   //New Regular Instalment, varchar(32)
                    "0,	           " +   //Loan Balance at Rescheduling, decimal(38,20)
                    "0,	           " +   //Loan Reschedule, tinyint
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "'," +   //Date Rescheduled, datetime
                    "'',	           " +   //Reschedule by, varchar(10)
                    "0,	           " +   //Flat Rate Principal, decimal(38,20)
                    "0,	           " +   //Flat rate Interest, decimal(38,20)
                    "0,	           " +   //Total Repayment, decimal(38,20)
                    "0,	           " +   //Interest Calculation Method, int
                    "0,	           " +   //Edit Interest Calculation Meth, tinyint
                    "0,	           " +   //Balance BF, decimal(38,20)
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "'," +   //Cheque Date, datetime
                    "0,	           " +   //Loan to Share Ratio, decimal(38,20)
                    "0,	           " +   //Shares Balance, decimal(38,20)
                    "0,	           " +   //Max_ Installments, int
                    "0,	           " +   //Max_ Loan Amount, decimal(38,20)
                    "0,	           " +   //Loan Cycle, int
                    "1,	           " +   //Repayment Method, int
                    "0,	           " +   //Grace Period - Principle (M), int
                    "0,	           " +   //Grace Period - Interest (M), int
                    "'',	       " +   //Adjustment, varchar(100)
                    "'',	       " +   //Payment Due Date, varchar(100)
                    "0,	           " +   //Tranche Number, int
                    "0,	           " +   //Amount Of Tranche, decimal(38,20)
                    "0,	           " +   //Total Disbursment to Date, decimal(38,20)
                    "0,	           " +   //Copy of ID, tinyint
                    "0,	           " +   //Contract, tinyint
                    "0,	           " +   //Payslip, tinyint
                    "0,	           " +   //Contractual Shares, decimal(38,20)
                    "0,	           " +   //Appraisal Status, int
                    "'',	           " +   //Global Dimension 1 Code, varchar(20)
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Repayment Start Date, datetime
                    "0,	           " +   //Installment Including Grace, int
                    "0,	           " +   //Repayments BF, decimal(38,20)
                    "'" + AccountNo + "',	           " +   //Account No, varchar(20)
                    "'',	           " +   //BOSA No, varchar(20)
                    "'',	           " +   //Staff No, varchar(20)
                    "0,	           " +   //BOSA Loan Amount, decimal(38,20)
                    "0,	           " +   //Loan Received, tinyint
                    "'',	           " +   //Cheque No_, varchar(20)
                    "0,	           " +   //Personal Loan Off-set, decimal(38,20)
                    "'',	           " +   //Old Account No_, varchar(20)
                    "0,	           " +   //Loan Principle Repayment, decimal(38,20)
                    "0,	           " +   //Loan Interest Repayment, decimal(38,20)
                    "'',	           " +   //Contra Account, varchar(20)
                    "'',	           " +   //Transacting Branch, varchar(20)
                    "1,	           " +   //Source, int
                    "0,	           " +   //Net Income, decimal(38,20)
                    "0,	           " +   //Shares Boosted, tinyint
                    "0,	           " +   //Basic Pay, decimal(38,20)
                    "0,	           " +   //House Allowance, decimal(38,20)
                    "0,	           " +   //Other Allowance, decimal(38,20)
                    "0,	           " +   //Total Deductions, decimal(38,20)
                    "0,	           " +   //Cleared Effects, decimal(38,20)
                    "'OK',	           " +   //Remarks, varchar(60)
                    "0,	           " +   //Advice, tinyint
                    "0,	           " +   //Bridging Loan Posted, tinyint
                    "'',	           " +   //BOSA Loan No_, varchar(20)
                    "0,	           " +   //Previous Repayment, decimal(38,20)
                    "0,	           " +   //No Loan in MB, tinyint
                    "0,	           " +   //Recovered Balance, decimal(38,20)
                    "0,	           " +   //Recon Issue, tinyint
                    "'',	           " +   //Loan Purpose, varchar(20)
                    "0,	           " +   //Reconciled, tinyint
                    "0,	           " +   //Appeal Amount, decimal(38,20)
                    "0,	           " +   //Appeal Posted, tinyint
                    "0,	           " +   //Project Amount, decimal(38,20)
                    "'',	           " +   //Project Account No, varchar(20)
                    "0,	           " +   //Discounted Amount, decimal(38,20)
                    "0,	           " +   //Transport Allowance, decimal(38,20)
                    "0,	           " +   //Mileage Allowance, decimal(38,20)
                    "0,	           " +   //System Created, tinyint
                    "0,	           " +   //Boosting Commision, decimal(38,20)
                    "0,	           " +   //Voluntary Deductions, decimal(38,20)
                    "0,	           " +   //4 % Bridging, tinyint
                    "0,	           " +   //Defaulted, tinyint
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Bridging Posting Date, datetime
                    "0,	           " +   //Commitements Offset, decimal(38,20)
                    "0,	           " +   //Gender, int
                    "'"+user.ToUpper() +"',	           " +   //Captured By, varchar(20)
                    "'',	           " +   //Branch Code, varchar(20)
                    "0,	           " +   //Recovered From Guarantor, tinyint
                    "0,	           " +   //Guarantor Amount, decimal(38,20)
                    "0,	           " +   //External EFT, tinyint
                    "'',	           " +   //Defaulter Overide Reasons, varchar(150)
                    "0,	           " +   //Defaulter Overide, tinyint
                    "0,	           " +   //Other Benefits, decimal(38,20)
                    "'',	           " +   //Recovered Loan, varchar(20)
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //1st Notice, datetime
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //2nd Notice, datetime
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Final Notice, datetime
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "',	           " +   //Last Advice Date, datetime
                    "0,	           " +   //Advice Type, int
                    "0,	           " +   //Compound Balance, decimal(38,20)
                    "0,	           " +   //Repayment Rate, decimal(38,20)
                    "[ID No_],	           " +   //ID NO, varchar(20)
                    "0,	           " +   //RAmount, decimal(38,20)
                    "'',	           " +   //Employer Code, varchar(20)
                    "0,	           " +   //Lst LN1, tinyint
                    "0,	           " +   //Lst LN2, tinyint
                    "0,	           " +   //Loans Category, int
                    "0,	           " +   //Loans Category-SASRA, int
                    "'',	           " +   //Bela Branch, varchar(10)
                    "0,	           " +   //Net Amount, decimal(38,20)
                    "'',	           " +   //Bank code, varchar(10)
                    "'',	           " +   //Bank Name, varchar(150)
                    "'',	           " +   //Bank Branch, varchar(150)
                    "0,	           " +   //Defaulter, tinyint
                    "'',	           " +   //DefaulterInfo, varchar(50)
                    "0,	           " +   //Total Earnings(Salary), decimal(38,20)
                    "0,	           " +   //Total Deductions(Salary), decimal(38,20)
                    "0,	           " +   //Share Purchase, decimal(38,20)
                    "'',	           " +   //Product Currency Code, varchar(30)
                    "'',	           " +   //Sacco Customer No_, varchar(20)
                    "0,	           " +   //Total Interest[For the period]], decimal(38,20)
                    "0,	           " +   //Average[Monthly Interest]], decimal(38,20)
                    "0,	           " +   //Monthly Repayment, decimal(38,20)
                    "0,	           " +   //Monthly Interest, decimal(38,20)
                    "0,	           " +   //Repayment Mode, int
                    "[No_],	           " +   //Vendor No_, varchar(50)
                    "'',	           " +   //ConfirmVendorNumber, varchar(10)
                    "'',	           " +   //Fosa Main[Bank]], varchar(50)
                    "'" + CUtilities.FormatDate(DateTime.Now, true) + "'	           " +   //Last pay Date[Old]], datetime
                    " from ["+ Companyname + "$Vendor] where [No_] = '" + AccountNo + "')");
            }
            catch (Exception ex)
            {
                result = ex.Message;
                CUtilities.LogEntryOnFile(ex.Message);
            }
            data.close();
            return result;
        }

        [WebMethod]
        public string NewRegistrations()
        {
            string Numbers = "";
            getsettings();
            data = new Data(server, db, user, pass);
            System.Data.DataTable reg = data.Getdatatable("SELECT * FROM ["+ Companyname + "$MPESA Applications] WHERE Status = 2 AND [Sent To Server] =0");
            if (reg.Rows.Count > 0)
            {
                foreach (System.Data.DataRow r in reg.Rows)
                {
                    Numbers += r["MPESA Mobile No"].ToString() + "|";
                    data.WriteDB("UPDATE ["+ Companyname + "$MPESA Applications] sET [Sent To Server] = 1 WHERE No = '" + r["No"] + "'");
                }

            }
            data.close();
            return Numbers;


        }
        [WebMethod]
        public string Sms()
        {
            string Numbers = "";
            getsettings();
            data = new Data(server, db, user, pass);
            System.Data.DataTable reg = data.Getdatatable("SELECT * FROM ["+ Companyname + "$SMS Messages] WHERE [Sent To Server] = 0 AND [Telephone No] <>''");
            if (reg.Rows.Count > 0)
            {
                
                foreach (System.Data.DataRow r in reg.Rows)
                {
                    Numbers += r["Telephone No"].ToString() + ":" + r["SMS Message"].ToString() + "|";
                    data.WriteDB("UPDATE ["+ Companyname + "$SMS Messages] SET [Sent To Server] = 1 WHERE [Entry No] = '" + r["Entry No"] + "'");
                }

            }
            data.close();
            return Numbers;


        }
        [WebMethod]
        public string PinRequest()
        {
            string Numbers = "";
            getsettings();
            data = new Data(server, db, user, pass);

            System.Data.DataTable reg = data.Getdatatable("SELECT * FROM ["+ Companyname + "$Change MPESA PIN No] WHERE Status = 1 AND [Sent To Server] =0");
            if (reg.Rows.Count > 0)
            {
                foreach (System.Data.DataRow r in reg.Rows)
                {
                    Numbers += r["MPESA Mobile No"].ToString() + "|";
                    data.WriteDB("UPDATE ["+ Companyname + "$Change MPESA PIN No] set [Sent To Server] = 1 WHERE No = '" + r["No"] + "'");
                }

            }
            data.close();
            return Numbers;
        }
    }
}
