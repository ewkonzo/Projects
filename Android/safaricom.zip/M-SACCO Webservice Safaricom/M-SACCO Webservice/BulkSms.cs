﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace M_SACCO_Webservice
{
    public class BulkSms
    {
        public int EntryNo = 0;
        public string Phone = "";
        public string Text = "";
        public string status = "";
        public int balance = 0;
        public Boolean updated = false;
        public Boolean Hasresults = true;
        public string Errors;
            }
}