package com.example.paul.a_sacco;

public class Account
{
  public double Account_Balance = 0.0D;
  public String Account_Name = null;
  public String Account_No = null;
  public boolean Account_ok = true;
  public String Account_type = null;
  public String Message = null;
  public boolean Selected = false;
  public String Telephone = null;
}


/* Location:              E:\Paul\Projects\Android\Agent Recovery\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\example\paul\a_sacco\Account.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */