package com.example.paul.a_sacco;

import java.util.List;

public class Member
{
  public String Society = null;
  public List<Account> accounts = null;
  public String id_no = null;
  public List<Loans> loans = null;
  public String message = null;
  public String name = null;
  public String pin;
  public boolean pin_changed = false;
  public boolean requestsuccessful = true;
  public String society_no = null;
  public String telephone = null;
}


/* Location:              E:\Paul\Projects\Android\Agent Recovery\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\example\paul\a_sacco\Member.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */