package com.example.paul.a_sacco;

public class Agent
{
  public boolean Pin_changed = false;
  public String Telephone = null;
  public double account_balance = 0.0D;
  public String agent_Account = null;
  public String agent_Name = null;
  public String agent_code = null;
  public boolean logged_in = false;
  public String message = null;
  public String new_pin = null;
  public String pin = null;
}


/* Location:              E:\Paul\Projects\Android\Agent Recovery\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\com\example\paul\a_sacco\Agent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */