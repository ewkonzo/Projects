package com.example.m_saccoagency;

public class Account {
    public String Account_No = null;
    public String Account_Name = null;
    public double Account_Balance = 0;
    public String Account_type = null;
    public String Telephone = null;
    public Boolean Selected = false;
    public Boolean Account_ok = true;
    public String Message = null;

}
