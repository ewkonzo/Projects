package com.example.m_saccoagency;

public class Societies
{
    public String name;
    public String code;
    public String memberid = null;
}
