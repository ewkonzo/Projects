package com.example.m_saccoagency;

public class Agent {

	  public boolean Pin_changed = false;
	  public String Telephone = null;
	  public double account_balance = 0.0D;
	  public String agent_Account = null;
	  public String agent_Name = null;
	  public String agent_code = null;
	  public boolean logged_in = false;
	  public String message = null;
	  public String new_pin = null;
	  public String pin = null;
}
