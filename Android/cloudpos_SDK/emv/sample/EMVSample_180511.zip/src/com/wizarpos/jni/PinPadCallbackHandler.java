package com.wizarpos.jni;

public interface PinPadCallbackHandler
{
	public void processCallback(byte[] data);
}
