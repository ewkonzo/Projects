﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S_Ussd
{
    public class Request
    {
        public static Data.MobileEntities db;
        public string MSISDN;
        public string SESSIONID;
        public string SERVICECODE;
        public string USSDSTRING;
        public  string clientCode;
        public string Currentoption;
        public  Data.Customer customer;
        public Data.Ussd session;
        public Data.Client client;
      
        public List<Data.Session> sessiondetails;
        public Transtype transtype;
       

        public static Request Saverequest(Request r)
        {

            Data.Ussd ussd =db.Ussds.FirstOrDefault(o => o.SESSION == r.SESSIONID) ;
            if (ussd == null)
            {
                ussd = new Data.Ussd();
                ussd.SESSION = r.SESSIONID;
                ussd.Phone = r.MSISDN;
                ussd.Transaction_Time = DateTime.Now;
                ussd.Code = r.SERVICECODE;
                ussd.Client = r.clientCode;
                
                db.Ussds.Add(ussd);
            }
            

            ussd.OPTION = r.Currentoption;
            ussd.USSD_STRING = r.USSDSTRING;
            ussd.Trans_Type = (int)r.transtype;
            ussd.Menu_Count =( r.session!=null ?r.session.Menu_Count:0);


            Data.Session s = new Data.Session();
            s.Code = r.SERVICECODE;
            s.SESSION_ID = r.SESSIONID;
            s.Value = r.Currentoption;
            db.Sessions.Add(s);

            return r;
        }
        public static void getsession(ref Request r) {
            Request rr = r;
                        r.session = Request.db.Ussds.FirstOrDefault(o => o.SESSION == rr.SESSIONID && o.Phone == rr.MSISDN);
            if (r.session != null)
            {
                r.transtype = (Transtype)r.session.Trans_Type;

                r.sessiondetails = Request.db.Sessions.Where(o => o.SESSION_ID == rr.SESSIONID).ToList();

            }
        }
     }
    public enum sessionstatus {
        CON,
        END
    }
    public class lang
    {
        public Request request;
        public response message;

        public static string getlang(sessionstatus s, Request l, response message, params object[] args)
        {
            string mes = message.ToString();
            string lan;
            if (l.customer == null)
                lan = "EN";
            else
                lan = l.customer.Language;
            return string.Format("{0} {1}", s.ToString(), string.Format( Request.db.Languages.FirstOrDefault(o => o.Languagecode == lan && o.Messagecode == mes).Message, args));
        }
    }
    public enum response
    {
        NotRegistered=0,
        NotActive = 1,
        pin = 2,
        selectclient = 3,
        Menu = 4,
        Repin = 5,
        Blocked = 6,
    }

    public enum Transtype
    {
        pinchange=0,
        selectclient =1,
        pin = 2,
        MyAccount = 3,
        Menu = 4,
             Repin = 5,
        start = 6,
    }
   
}
