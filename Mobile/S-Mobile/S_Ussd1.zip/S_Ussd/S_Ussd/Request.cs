﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S_Ussd
{
    public class useroptions
    {
        public static string Menu(ref Request r, List<Data.Menu> m)
        {
            string menu = string.Empty;
            try
            {
                int i = 1;
                foreach (Data.Menu mm in m)
                {
                    Data.User_Option nm = new Data.User_Option();
                    nm.Acc = mm.ID.ToString();
                    nm.Name = mm.Menu1;
                    nm.Session = r.SESSIONID;
                    nm.Selection = i;
                    nm.Option = (int)enums.options.Menu;
                    Request.db.User_Options.Add(nm);
                    menu = string.Format("{0}{1}. {2}{3}", menu, i, nm.Name, Request.newline);
                    i += 1;
                }
            }
            catch (Exception ex) { Logging.Logging.ReportError(ex); }

            return menu;
        }
        public static string accounts(ref Request r, List<account> m)
        {
            string str1 = string.Empty;
            try
            {
                int i = 1;
                foreach (account mm in m)
                {
                    Data.User_Option nm = new Data.User_Option();
                    nm.Acc = mm.No.ToString();
                    nm.Name = mm.Name;
                    nm.Session = r.SESSIONID;
                    nm.Value = mm.Balance;
                    nm.Selection = i;
                    nm.Option = (int)enums.options.Withacc;
                    Request.db.User_Options.Add(nm);
                    str1 = string.Format("{0}{1}. {2}{3}", str1, i, nm.Acc, Request.newline);
                    i += 1;
                }
            }
            catch (Exception ex) { Logging.Logging.ReportError(ex); }

            return str1;
        }
        public static void selectedmenu(ref Request r)
        {

            Request rr = r;
            var usersel = int.Parse(userselection(rr, enums.options.Menu).Acc);
            var d = Request.db.Menus.FirstOrDefault(o => o.ID ==usersel );
            r.session.Menu = d.ID;


        }
        public static Data.User_Option userselection(Request r,enums.options e)
        {
            var usersel = int.Parse(r.Currentoption);
            int ee = (int)e;
            return Request.db.User_Options.FirstOrDefault(o => o.Selection ==usersel && o.Session == r.SESSIONID && o.Option == ee);
        }
    }
    public class Request
    {
        public static Data.MobileEntities db;
        public static string newline = "&#x000a;";
        public string MSISDN;
        public string SESSIONID;
        public string SERVICECODE;
        public string USSDSTRING;
        public string clientCode;
        public string Currentoption;
        public Data.Customer customer;
        public Data.Ussd session;
        public Data.Client client;
        public List<Data.Session> sessiondetails;
        public Data.Transaction transaction;
        public Data.Session lastsession;
        public static string common= string.Format("{0}00. Home{0} 000. Logout", newline); 
    }
    public class lang
    {
        public Request request;
        public enums.response message;
        public static string getlang(enums.sessionstatus s, ref Request l, enums.response message, params object[] args)
        {
            string mes = message.ToString();
            string lan;
            if (l.customer == null)
                lan = "EN";
            else
                lan = l.customer.Language;

            Data.Session ss = new Data.Session();
            ss.SESSION_ID = l.SESSIONID;
            ss.Value = l.Currentoption;
            ss.Option = (int)message;
            Request.db.Sessions.Add(ss);
             return  string.Format("{0} {1}", s.ToString(), string.Format(Request.db.Languages.FirstOrDefault(o => o.Languagecode == lan && o.Messagecode == mes).Message, args));
          //  return string.Concat( string.Format("{0} {1}", s.ToString(), string.Format(Request.db.Languages.FirstOrDefault(o => o.Languagecode == lan && o.Messagecode == mes).Message, args)),Request.common);
        }
    }
    public class enums
    {
        public enum options
        {
            Menu=0,Withacc=1

        }
        public enum sessionstatus
        {
            CON,
            END
        }
        public enum Status
        {
            Processing = 0,
            Pending = 1,
            Completed = 2,
            Failed = 3
        }
        public enum response
        {
            NotRegistered = 0,
            NotActive = 1,
            pin = 2,
            selectclient = 3,
            Menu = 4,
            Repin = 5,
            Blocked = 6,
            balance = 7,
            insufficientfunds = 8,
            Ministatement = 9,
            selectacc = 10,
            Noaccount = 11,
            sendto = 12,
            amount = 13,
            otherTelephone = 14,
            Invalidentry = 15,
            withdrawalconfirm = 16,
            withdrawal = 17,
            cancelwithdrawal = 18,
        }
        public enum Transtype
        {
            /// <remarks/>
            _blank_,

            /// <remarks/>
            Withdrawal,

            /// <remarks/>
            Deposit,

            /// <remarks/>
            Balance,

            /// <remarks/>
            Ministatement,

            /// <remarks/>
            Airtime,

            /// <remarks/>
            Loan_balance,

            /// <remarks/>
            Loan_Status,

            /// <remarks/>
            Share_Deposit_Balance,

            /// <remarks/>
            Transfer_to_Fosa,

            /// <remarks/>
            Transfer_to_Bosa,

            /// <remarks/>
            Utility_Payment,

            /// <remarks/>
            Loan_Application,

            /// <remarks/>
            Standing_orders,
        }
        public enum Menu
        {
            Balance = 1,
            Ministatement = 2,
            Withdrawal = 3
        }
    }
    public class account
    {
        public string No;
        public string Name;
        public Stat Status;
        public double Balance;
        public enum Stat
        {

            /// <remarks/>
            Active,

            /// <remarks/>
            Frozen,

            /// <remarks/>
            Closed,

            /// <remarks/>
            Archived,

            /// <remarks/>
            New,

            /// <remarks/>
            Dormant,

            /// <remarks/>
            Deceased,
        }
        public account(string no, string name, Stat status, double balance) {
            No = no;
            Name = name;
            Status = status;
            Balance = balance;

        }
    }
    public class client
    {
        public static S_mobileClient.Client smobile = new S_mobileClient.Client();
        public static List<account> Accounts(string tel)
        {  List<account> Account = new List<account>();
            try
            {
                var a = smobile.Accounts("+" +tel);
                foreach (S_mobileClient.Accounts ac in a)
                {
                    Account.Add(new account(ac.noField, ac.nameField, (account.Stat)ac.statusField, (double)ac.balanceField));
                }
            }
            catch (Exception ex)
            {
                Logging.Logging.ReportError(ex);
            }
            return Account;
        }
        public static double Balance(ref Request r)
        {
            double bal =0;
            try
            {
                var t =   Trans(ref r);
               
               bal =(double) smobile.Account(r.transaction.Account_No).balanceField;
            }catch(Exception ex) { Logging.Logging.ReportError(ex); }
        return bal; }
        public static double Tcharges(double amount, enums.Transtype type)
        {
            double bal = 0;
            return bal;
        }

        public static string ministatement(ref Request r)
        {
            StringBuilder mini = new StringBuilder();
            try
            {
                r.transaction.Min_size = 5;
             var t =   Trans(ref r);
                if (t.code == 0)
                    foreach (S_mobileClient.Ministatement min in t.Mini)
                    {
                        mini.AppendLine(string.Format("{0}:{1}:{2}:{3}",min.posting_Date.ToShortDateString(),(min.amount>0?"CR":"DR"), min.amount,min.desc));
                   }
            }
            catch (Exception ex)
            { Logging.Logging.ReportError(ex); }
            return mini.ToString();
        }
        public static S_mobileClient.Trans Trans (ref Request t)
        {
            S_mobileClient.Trans trans= new S_mobileClient.Trans();
            try {
                trans.Account_No = t.transaction.Account_No;
                trans.Document_No = t.transaction.Reference;
                trans.Document_Date = DateTime.Now.Date;
                trans.Transaction_Time = DateTime.Now;
                trans.Transaction_Type =(int) t.transaction.Transaction_type;
                trans.Account_2 = t.transaction.Account_2;
                trans.Charge =(decimal) t.transaction.Charge;
                trans.Amount = (decimal)t.transaction.Amount;
                trans.Telephone_Number = t.transaction.Telephone;
                trans = smobile.Transaction(trans);
                t.transaction.Status =  trans.code;
                t.transaction.Comments = trans.Comments;
              
            }

            catch (Exception ex) { Logging.Logging.ReportError(ex); }
            return trans;
        }
    }
   
}
