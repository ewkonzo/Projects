﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Logs = Logging.Logging;
using Data;

namespace S_Ussd
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class S_Mobile : WebService
    {
        public string res = "END Thank You for using S-MOBILE";

        public static Request req = new Request();
        public lang lang = new lang();

        public S_Mobile()
        {
            Logging.Logging.logpath = @"F:\Paul\Logs\Ussd\";
            var connectionstring = data.Connectionstring(@".\", "Mobile");
            Request.db = new MobileEntities(connectionstring);
        }
        [WebMethod]
        public void USSD(string MSISDN, string SESSION_ID, string SERVICE_CODE, string USSD_STRING)
        {
            try
            {
                String[] coption = USSD_STRING.Split(new Char[] { '*' }, StringSplitOptions.None);
                req.MSISDN = MSISDN;
                req.SESSIONID = SESSION_ID;
                req.SERVICECODE = SERVICE_CODE;
                req.USSDSTRING = USSD_STRING;
                req.Currentoption = coption[coption.GetUpperBound(0)];
                lang.request = req;
                res = Menu();
            }
            catch (Exception ex)
            {
                Logs.ReportError(ex);
            }

            Context.Response.Write(res);
        }
        public string Menu()
        {
            using (Request.db = new MobileEntities(data.Connectionstring(@".\", "Mobile")))
            {
                try
                {
                    if (string.IsNullOrEmpty(req.USSDSTRING))
                    {
                        req.session = new Data.Ussd();
                        req.session.SESSION = req.SESSIONID;
                        req.session.Phone = req.MSISDN;
                        req.session.Transaction_Time = DateTime.Now;
                        req.session.Code = req.SERVICECODE;
                        req.session.Status = (int)enums.Status.Processing;
                        Request.db.Ussds.Add(req.session);
                        req.transaction = new Transaction();
                        req.transaction.Reference = req.SESSIONID;
                        req.transaction.MSISDN = req.MSISDN;
                        req.transaction.Transaction_Date = DateTime.Now;
                        Request.db.Transactions.Add(req.transaction);

                        var cust = Request.db.Customers.Where(o => o.Telephone == req.MSISDN).ToList();

                        if (cust.Count() == 0)
                        {
                            req.session.Status = (int)enums.Status.Failed;
                            req.session.Comments = "Not Registered";
                            return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.NotRegistered);
                        }

                        if (cust.Count() > 1)
                        {
                            return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.selectclient);
                        }

                        if (cust[0].Active == false)
                        {
                            req.session.Status = (int)enums.Status.Failed;
                            req.session.Comments = "Not Active";
                            return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.NotActive);
                        }

                        req.customer = cust[0];
                        req.session.Client = cust[0].Client;
                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.pin);
                    }
                    else
                    {
                        req.transaction = Request.db.Transactions.FirstOrDefault(o => o.Reference == req.SESSIONID);
                        req.session = Request.db.Ussds.FirstOrDefault(o => o.SESSION == req.SESSIONID);
                        if (req.session != null)
                        {
                            req.sessiondetails = Request.db.Sessions.Where(o => o.SESSION_ID == req.SESSIONID).ToList();
                            req.customer = Request.db.Customers.FirstOrDefault(o => o.Telephone == req.MSISDN);

                            if (!string.IsNullOrEmpty(req.session.Client))

                                req.client = Request.db.Clients.FirstOrDefault(o => o.Client_Code == req.session.Client);

                            return pin();

                        }
                    }

                }
                catch (Exception ex)
                {
                    Logs.ReportError(ex);
                }
                finally
                {

                    Request.db.SaveChanges();
                }
            }
            return res;

        }
        private string pin()
        {
            string res = string.Empty;
            var r = req.sessiondetails.OrderByDescending(o => o.Id).FirstOrDefault();

            switch ((enums.response)r.Option)
            {
                case enums.response.pin:
                    return Validatepin();
                default:
                    useroptions.selectedmenu(ref req);
                    return menu(ref req);

            }

        }

        private string Validatepin()
        {

            try
            {
                var login = Request.db.Logins.FirstOrDefault(o => o.Telephone == req.MSISDN && o.PIN_Encrypted == req.Currentoption);
                if (login != null)
                {
                    var menu = Request.db.Menus.Where(o => o.Client == req.client.Client_Code && o.Active == true).ToList();

                    res = lang.getlang(enums.sessionstatus.CON, ref req, enums.response.Menu, Request.newline, useroptions.Menu(ref req, menu));
                }
                else {
                    if ((req.session != null) && (req.session.Menu_Count != null) && (req.client != null))
                        if (req.session.Menu_Count >= req.client.Pin_retries)
                        {
                            res = lang.getlang(enums.sessionstatus.END, ref req, enums.response.Blocked);
                        }
                        else {
                            req.session.Menu_Count += 1;
                            res = lang.getlang(enums.sessionstatus.CON, ref req, enums.response.Repin, (req.client.Pin_retries - req.session.Menu_Count));
                        }
                }
            }
            catch (Exception ex)
            { Logging.Logging.ReportError(ex); }
            return res;
        }

        private string menu(ref Request r)
        {
            try
            {
                var lastsession = r.sessiondetails.OrderByDescending(o => o.Id).FirstOrDefault();
                r.transaction.Client = r.client.Client_Code;
                switch ((enums.Menu)req.session.Menu)
                {
                    #region balance
                    case enums.Menu.Balance:
                        switch ((enums.response)lastsession.Option)
                        {
                            #region Getaccount
                            case enums.response.Menu:
                                r.transaction.Transaction_type = (int)enums.Transtype.Balance;
                                var accounts = client.Accounts(req.MSISDN);
                                if (accounts.Count() == 0)
                                    return lang.getlang(enums.sessionstatus.END, ref req, enums.response.Noaccount);
                                if (accounts.Count() > 1)
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.selectacc, Request.newline, useroptions.accounts(ref req, accounts));
                                else
                                {
                                    r.transaction.Account_No = accounts[0].No;
                                    goto case enums.response.selectacc;
                                }
                            #endregion
                            #region Show balance
                            case enums.response.selectacc:
                                var selection = useroptions.userselection(r, enums.options.Withacc);
                                if (String.IsNullOrEmpty(r.transaction.Account_No))
                                    r.transaction.Account_No = selection.Acc;

                                double bal = client.Balance(r.transaction.Account_No);
                                if (r.client.Show_bal_for_overdrawan_acc == true)
                                {
                                    client.Trans(ref req);
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.balance, r.transaction.Account_No, bal)
                                   ;
                                }
                                else
                                {
                                    if (bal >= client.Tcharges(0, enums.Transtype.Balance))
                                    {
                                        client.Trans(ref req);
                                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.balance, r.transaction.Account_No, bal);
                                    }
                                    else
                                    {
                                        r.transaction.Status = (int)enums.Status.Failed;
                                        r.transaction.Comments = "Insufficcient funds";
                                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.insufficientfunds);
                                    }
                                }
                                #endregion
                        }
                        break;
                    #endregion
                    #region Ministatement
                    case enums.Menu.Ministatement:
                        switch ((enums.response)lastsession.Option)
                        {
                            #region Getaccount
                            case enums.response.Menu:
                                r.transaction.Transaction_type = (int)enums.Transtype.Ministatement;
                                var accounts = client.Accounts(req.MSISDN);
                                if (accounts.Count() == 0)
                                    return lang.getlang(enums.sessionstatus.END, ref req, enums.response.Noaccount);
                                if (accounts.Count() > 1)
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.selectacc, Request.newline, useroptions.accounts(ref req, accounts));
                                else
                                {
                                    r.transaction.Account_No = accounts[0].No;
                                    goto case enums.response.selectacc;
                                }
                            #endregion
                            #region Show Ministatement
                            case enums.response.selectacc:
                                var selection = useroptions.userselection(r, enums.options.Withacc);
                                if (String.IsNullOrEmpty(r.transaction.Account_No))
                                    r.transaction.Account_No = selection.Acc;

                                double bal = client.Balance(r.transaction.Account_No);

                                if (r.client.Show_bal_for_overdrawan_acc == true)
                                {
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.Ministatement, client.ministatement(ref r));
                                }
                                else
                                {
                                    if (bal >= client.Tcharges(0, (enums.Transtype)r.transaction.Transaction_type))
                                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.Ministatement, client.ministatement(ref r));

                                    else
                                    {
                                        r.transaction.Status = (int)enums.Status.Failed;
                                        r.transaction.Comments = "Insufficcient funds";
                                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.insufficientfunds);
                                    }
                                }
                                #endregion
                        }
                        break;
                    #endregion
                    #region Withdrawal
                    case enums.Menu.Withdrawal:
                        switch ((enums.response)lastsession.Option)
                        {
                            #region Getaccount
                            case enums.response.Menu:
                                r.transaction.Transaction_type = (int)enums.Transtype.Withdrawal;
                                var accounts = client.Accounts(req.MSISDN);
                                if (accounts.Count() == 0)
                                    return lang.getlang(enums.sessionstatus.END, ref req, enums.response.Noaccount);

                                if (accounts.Count() > 1)
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.selectacc, Request.newline, useroptions.accounts(ref req, accounts));
                                else
                                {
                                    r.transaction.Account_No = accounts[0].No;
                                    goto case enums.response.selectacc;
                                }
                            #endregion
                            #region Select Destination
                            case enums.response.selectacc:
                                var selection = useroptions.userselection(r, enums.options.Withacc);
                                if (String.IsNullOrEmpty(r.transaction.Account_No))
                                    r.transaction.Account_No = selection.Acc;
                                return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.sendto, Request.newline);
                            #endregion
                            #region Destination
                            case enums.response.sendto:
                                switch (r.Currentoption)
                                {
                                    case "1":
                                        r.transaction.Telephone = r.MSISDN;
                                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.amount, Request.newline);

                                    case "2":
                                        return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.otherTelephone, Request.newline);
                                }
                                break;
                            #endregion
                            #region other telephone
                            case enums.response.otherTelephone:
                                r.transaction.Telephone = r.Currentoption;
                                return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.amount, Request.newline);

                            #endregion
                            #region amount
                            case enums.response.amount:
                                double amount;
                                if (double.TryParse(r.Currentoption, out amount))
                                    r.transaction.Amount = amount;
                                else
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.Invalidentry, Request.newline);
                                double bal = client.Balance(r.transaction.Account_No);
                                r.transaction.Charge = (double)r.transaction.Amount + client.Tcharges((double)r.transaction.Amount, enums.Transtype.Withdrawal);

                                if (bal >= r.transaction.Charge)
                                    return lang.getlang(enums.sessionstatus.CON, ref req, enums.response.withdrawalconfirm, Request.newline, r.transaction.Amount, r.transaction.Account_No, r.transaction.Telephone);
                                else
                                    return lang.getlang(enums.sessionstatus.END, ref req, enums.response.insufficientfunds, Request.newline);
                            #endregion
                            #region Confirm
                            case enums.response.withdrawalconfirm:
                                switch (r.Currentoption)
                                {
                                    case "1":
                                        r.transaction.Status = enums.Status.Completed.ToString();
                                        return lang.getlang(enums.sessionstatus.END, ref req, enums.response.withdrawal, Request.newline);
                                    case "2":
                                        r.transaction.Status = enums.Status.Failed.ToString();
                                        r.transaction.Comments = "User cancelled";
                                        return lang.getlang(enums.sessionstatus.END, ref req, enums.response.cancelwithdrawal, Request.newline);
                                }
                                break;
                                #endregion
                        }
                        break;
                        #endregion
                }
            }
            catch (Exception ex)
            {
                r.transaction.Status = (int)enums.Status.Failed;
                r.transaction.Comments = ex.Message;
                Logging.Logging.ReportError(ex);
            }
            return res;
        }
        private string chooseclient(ref List<Customer> customer)
        {

            return "";
        }
    }
}